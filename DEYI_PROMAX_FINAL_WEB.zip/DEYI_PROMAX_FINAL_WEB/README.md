# DEYI PROMAX — Pack Web final

## Fichier principal
`DEYI_PROMAX.html`

L'application est servie par `server.mjs`. En hébergement Web, l'utilisateur ouvre simplement l'URL HTTPS du service dans Chrome. La page `/` sert automatiquement `DEYI_PROMAX.html`.

## Structure
- `DEYI_PROMAX.html` — interface et logique de l'application
- `server.mjs` — serveur HTTP + relais Internet
- `package.json` — démarrage Node.js
- `render.yaml` — configuration Render
- `Dockerfile` — déploiement Docker
- `.env.example` — variables d'environnement

## Déploiement Render
- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`
- Health check: `/health`

Render fournit une URL HTTPS publique. Ouvrir cette URL dans Chrome.

## Important
Ne pas ouvrir `DEYI_PROMAX.html` avec `file://` si l'on veut utiliser le relais serveur. Il faut ouvrir l'URL Web du serveur.

Les requêtes de score exact sont exécutées consécutivement : Forebet → PredictZ → Score-Exact. Une source en échec n'empêche pas les suivantes d'être interrogées. Aucun score local/fictif n'est utilisé.

FootyStats nécessite une clé API valide dans `FOOTYSTATS_API_KEY` pour les données API correspondantes.
