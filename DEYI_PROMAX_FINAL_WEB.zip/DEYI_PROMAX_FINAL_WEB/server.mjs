import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const ROOT = path.dirname(fileURLToPath(import.meta.url));
const APP = path.join(ROOT, 'DEYI_PROMAX.html');
const TIMEOUT = 15000;

function timeoutSignal(ms = TIMEOUT) { return AbortSignal.timeout(ms); }
async function fetchText(url, headers={}) {
  const r = await fetch(url, { headers: { 'user-agent': 'DEYI-PROMAX/2.0 (+relay)', accept: 'text/html,application/json;q=0.9,*/*;q=0.8', ...headers }, signal: timeoutSignal() });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return { text: await r.text(), url: r.url, contentType: r.headers.get('content-type') || '' };
}
async function fetchJson(url, headers={}) {
  const r = await fetch(url, { headers: { 'user-agent': 'DEYI-PROMAX/2.0 (+relay)', accept: 'application/json,text/plain;q=0.9,*/*;q=0.8', ...headers }, signal: timeoutSignal() });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return { data: await r.json(), url: r.url };
}
function cleanHtml(html) {
  return String(html).replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<noscript[\s\S]*?<\/noscript>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&#39;/g,"'").replace(/&quot;/gi,'"').replace(/\s+/g,' ').trim();
}
function norm(s) { return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/&/g,' and ').replace(/\b(football club|fc|cf|sc|ac|afc|club|calcio|fk|sv|vfb|as|rc|the)\b/g,' ').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' '); }
function sameTeam(a,b) { const A=norm(a),B=norm(b); if(!A||!B)return false; if(A===B)return true; const aa=new Set(A.split(' ').filter(x=>x.length>=2)), bb=new Set(B.split(' ').filter(x=>x.length>=2)); let hit=0; for(const x of aa)if(bb.has(x))hit++; return hit/Math.max(aa.size,bb.size)>=0.75; }
function isoFromQuery(v){ return /^\d{4}-\d{2}-\d{2}$/.test(v||'')?v:null; }
function score(v){ const m=String(v||'').match(/\b(\d{1,2})\s*[-–—:]\s*(\d{1,2})\b/); return m ? `${Number(m[1])}-${Number(m[2])}` : null; }
function json(res, status, data){ const body=JSON.stringify(data); res.writeHead(status, {'content-type':'application/json; charset=utf-8','cache-control':'no-store','access-control-allow-origin':'*'}); res.end(body); }
function send(res,status,body,type){res.writeHead(status,{'content-type':type,'cache-control':'no-store'});res.end(body);}

async function matchesSofa(date){
  const {data,url}=await fetchJson(`https://www.sofascore.com/api/v1/sport/football/scheduled-events/${date}`);
  return (data.events||[]).map(e=>({id:e.id,homeTeam:e.homeTeam?.name,awayTeam:e.awayTeam?.name,competition:e.tournament?.name,country:e.tournament?.category?.name,status:e.status?.type,startTimestamp:e.startTimestamp})).filter(x=>x.homeTeam&&x.awayTeam);
}
async function matchesFotMob(date){
  const {data}=await fetchJson(`https://www.fotmob.com/api/matches?date=${encodeURIComponent(date)}`);
  const groups=Array.isArray(data?.leagues)?data.leagues:[]; const out=[];
  for(const g of groups){ for(const e of (g.matches||[])){ const home=e.home?.name||e.homeTeam?.name, away=e.away?.name||e.awayTeam?.name; if(!home||!away)continue; const ts=e.status?.utcTime||e.utcTime||e.startTime; out.push({id:e.id,homeTeam:home,awayTeam:away,competition:g.name||g.leagueName||'Compétition',country:g.ccode||'',status:e.status?.started?'live':(e.status?.finished?'finished':'upcoming'),startTimestamp:ts?Math.floor(new Date(ts).getTime()/1000):undefined}); }}
  return out;
}
async function matchesFootyStats(date){
  const key=process.env.FOOTYSTATS_API_KEY;
  if(!key) throw new Error('FOOTYSTATS_API_KEY non configurée');
  const {data}=await fetchJson(`https://api.football-data-api.com/todays-matches?key=${encodeURIComponent(key)}&date=${encodeURIComponent(date)}&timezone=UTC`);
  const arr=Array.isArray(data?.data)?data.data:Array.isArray(data)?data:[];
  return arr.map(e=>({id:e.id,homeTeam:e.home_name,awayTeam:e.away_name,competition:e.competition_name||e.league_name||'Compétition',country:e.country_name||'',status:e.status==='complete'?'finished':'upcoming',startTimestamp:e.date_unix})).filter(x=>x.homeTeam&&x.awayTeam);
}
async function matches(source,date){ if(source==='sofascore')return matchesSofa(date); if(source==='fotmob')return matchesFotMob(date); if(source==='footystats')return matchesFootyStats(date); throw new Error('Source de matchs inconnue'); }

function exactUrl(source,date){
  if(source==='forebet') return `https://www.forebet.com/en/football-predictions/predictions-1x2/${date}`;
  if(source==='predictz') return 'https://www.predictz.com/predictions/today/correct-score/all-games/';
  return 'https://score-exact.com/aujourdhui/';
}
async function exact(source,home,away,date,competition){
  const url=exactUrl(source,date);
  const page=await fetchText(url);
  const text=cleanHtml(page.text);
  const H=norm(home), A=norm(away);
  if(!H||!A) return {homeTeam:home,awayTeam:away,dateISO:date,sourceUrl:url,status:'rejected',error:'Équipes invalides'};

  // La validation est locale au match : les deux équipes + la date doivent apparaître
  // dans la même fenêtre. Aucun score voisin n'est accepté.
  const positions=[];
  for(const q of [H,A]){
    let at=0;
    while(q){
      const p=text.toLowerCase().indexOf(q,at);
      if(p<0) break;
      positions.push(p); at=p+q.length;
      if(positions.length>60) break;
    }
  }
  const rx=/\b(\d{1,2})\s*[-–—:]\s*(\d{1,2})\b/g;
  const dateVariants=[date, `${date.slice(8,10)}/${date.slice(5,7)}/${date.slice(0,4)}`, `${date.slice(8,10)}-${date.slice(5,7)}-${date.slice(0,4)}`];
  for(const p of positions.sort((a,b)=>a-b)){
    const w=text.slice(Math.max(0,p-600),Math.min(text.length,p+1000));
    const low=norm(w);
    const hTokens=H.split(' ').filter(x=>x.length>=2);
    const aTokens=A.split(' ').filter(x=>x.length>=2);
    const hHit=hTokens.length===0||hTokens.some(x=>low.split(' ').includes(x));
    const aHit=aTokens.length===0||aTokens.some(x=>low.split(' ').includes(x));
    if(!hHit||!aHit) continue;

    // Si la page contient des dates, exiger la date demandée dans la fenêtre.
    const hasAnyDate=/\b20\d{2}[-/]\d{1,2}[-/]\d{1,2}\b|\b\d{1,2}[/-]\d{1,2}[/-]20\d{2}\b/.test(w);
    if(hasAnyDate && !dateVariants.some(d=>w.includes(d))) continue;

    const labelled=w.match(/(?:correct\s*score|exact\s*score|predicted\s*score|prediction|score\s*exact|pronostic)\D{0,120}(\d{1,2})\s*[-–—:]\s*(\d{1,2})/i);
    if(labelled){
      return {homeTeam:home,awayTeam:away,dateISO:date,score:`${Number(labelled[1])}-${Number(labelled[2])}`,sourceUrl:url,status:'verified',source,competition};
    }
    const found=[...w.matchAll(rx)].map(m=>`${Number(m[1])}-${Number(m[2])}`);
    const unique=[...new Set(found)];
    if(unique.length===1) return {homeTeam:home,awayTeam:away,dateISO:date,score:unique[0],sourceUrl:url,status:'verified',source,competition};
    if(unique.length>1) continue;
  }
  return {homeTeam:home,awayTeam:away,dateISO:date,sourceUrl:url,status:'unavailable',error:'Match + date + score exact non trouvés ou ambigus',source,competition};
}

async function route(req,res){
  const u=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  if(req.method==='OPTIONS'){res.writeHead(204,{'access-control-allow-origin':'*','access-control-allow-methods':'GET,OPTIONS','access-control-allow-headers':'*'});return res.end();}
  if(u.pathname==='/health'){return json(res,200,{ok:true,service:'DEYI PROMAX relay',time:new Date().toISOString(),node:process.version});}
  if(u.pathname==='/api/matches'){
    try{ const source=u.searchParams.get('source'),date=isoFromQuery(u.searchParams.get('date')); if(!source||!date)return json(res,400,{error:'source et date requis'}); return json(res,200,{matches:await matches(source,date),source,retrievedAt:new Date().toISOString()}); }
    catch(e){return json(res,502,{error:e.message});}
  }
  const map={'/api/source/forebet':'forebet','/api/source/predictz':'predictz','/api/source/score-exact':'scoreExact'};
  if(map[u.pathname]){
    try{ const home=u.searchParams.get('home'),away=u.searchParams.get('away'),date=isoFromQuery(u.searchParams.get('date')); if(!home||!away||!date)return json(res,400,{error:'home, away et date requis'}); const r=await exact(map[u.pathname],home,away,date,u.searchParams.get('competition')||''); return json(res,200,r); }
    catch(e){return json(res,502,{error:e.message});}
  }
  if(u.pathname==='/'||u.pathname==='/index.html'||u.pathname==='/DEYI_PROMAX.html'){
    try{return send(res,200,await fs.readFile(APP,'utf8'),'text/html; charset=utf-8');}catch(e){return json(res,500,{error:e.message});}
  }
  return json(res,404,{error:'Not found'});
}
http.createServer((req,res)=>route(req,res).catch(e=>json(res,500,{error:e.message||'Server error'}))).listen(PORT,HOST,()=>console.log(`DEYI PROMAX relay: http://${HOST==='0.0.0.0'?'localhost':HOST}:${PORT}`));
